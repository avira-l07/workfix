import json, math, time, traceback
from pathlib import Path
import torch
import pytorch_lightning as pl
from omegaconf import OmegaConf
import kathbath_tamil_pilot as p

repo = Path.cwd()
target = repo / 'same-dev-baseline-report.json'
if target.exists():
    raise RuntimeError('Same-dev baseline already has a report; preserve and share it')
report = {'status': 'Original model same-dev check not completed', 'training': 'Not run in this check',
          'app_promotion': 'Not done'}
try:
    plan = p.verify_plan(repo)
    baseline = json.loads((repo / 'baseline-report.json').read_text(encoding='utf-8'))
    if not baseline.get('ctc_baseline_gate_passed') or p.digest(baseline['checkpoint']) != baseline['checkpoint_sha256']:
        raise RuntimeError('Original source checkpoint/baseline verification failed')
    actual_runtime = p.runtime()
    pl.seed_everything(17, workers=True)
    trainer = pl.Trainer(accelerator='gpu', devices=1, precision='32-true', logger=False,
                         enable_checkpointing=False, num_sanity_val_steps=0)
    model = p.restore(baseline['checkpoint'], torch.device('cpu'), trainer=trainer)
    model.change_decoding_strategy(decoder_type='ctc', lang_id='ta')
    multi = 'multisoftmax' in model.cfg.decoder
    cfg = {'manifest_filepath': plan['manifests']['dev'], 'sample_rate': 16000, 'batch_size': 1,
           'shuffle': False, 'num_workers': 0, 'pin_memory': True,
           'min_duration': 1, 'max_duration': 10, 'trim_silence': False, 'is_tarred': False,
           'return_sample_id': multi, 'return_language_id': multi}
    model.setup_validation_data(OmegaConf.create(cfg))
    started = time.perf_counter()
    metrics = trainer.validate(model, verbose=False)[0]
    wer = float(metrics['val_wer_ctc'])
    if not math.isfinite(wer) or wer < 0:
        raise RuntimeError('Invalid same-dev source CTC WER')
    comparisons = []
    for mode in ('freeze-lower', 'full'):
        for seed in (17, 29):
            result = json.loads((repo / f'pilot-{mode}-{seed}/report.json').read_text(encoding='utf-8'))
            if (result.get('status') != 'Bounded pilot executed; full trial and held-out comparison not run'
                    or result.get('training_precision') != '32-true' or not result.get('weights_changed')
                    or result.get('global_step') != 20 or result.get('error')
                    or result.get('plan_sha256') != p.digest(repo / 'pilot-plan.json')
                    or result.get('baseline_report_sha256') != p.digest(repo / 'baseline-report.json')):
                raise RuntimeError('Pilot comparison requires completed runs from the exact same plan/baseline')
            dev = [row for row in result['history'] if 'dev_ctc_wer' in row]
            pilot_wer = float(dev[-1]['dev_ctc_wer'])
            if not math.isfinite(pilot_wer):
                raise RuntimeError('Non-finite pilot development WER')
            comparisons.append({'mode': mode, 'seed': seed, 'last_dev_ctc_wer': pilot_wer,
                                'change_from_source_percentage_points': 100 * (pilot_wer - wer)})
    report.update(status='Original source and pilot CTC compared on the same 64-clip DEV subset',
                  count=plan['counts']['dev'], source_dev_ctc_wer=wer,
                  source_checkpoint_sha256=baseline['checkpoint_sha256'],
                  plan_sha256=p.digest(repo / 'pilot-plan.json'), evaluation_precision='32-true',
                  runtime=actual_runtime, elapsed_seconds=time.perf_counter() - started,
                  comparisons=comparisons, heldout_after_training='Not run')
except Exception:
    import os
    report.update(status='Same-dev source check failed; preserve and share report',
                  traceback=traceback.format_exc().replace(os.environ.get('HF_TOKEN') or '<no-token>', '[REDACTED]')[-12000:])
    raise
finally:
    p.write_json(target, report)
print(json.dumps(report, indent=2))
