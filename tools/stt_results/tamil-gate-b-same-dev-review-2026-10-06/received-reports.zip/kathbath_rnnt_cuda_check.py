from kathbath_tamil_pilot import runtime, write_json, verify_plan
def rnnt_cuda_preflight():
    """Exercise the exact CUDA interop/loss path before loading a large model."""
    import importlib.metadata as metadata
    import torch
    from numba import cuda
    from numba.cuda.cudadrv import driver
    from nemo.collections.asr.losses.rnnt import RNNTLoss
    if not driver.USE_NV_BINDING or metadata.version("cuda-python") != "12.4.0":
        raise RuntimeError("Install cuda-python==12.4.0 and set NUMBA_CUDA_USE_NVIDIA_BINDING=1 before importing Numba")
    checked = runtime()
    checked.update(numba=metadata.version("numba"), cuda_python=metadata.version("cuda-python"),
                   numba_cuda_use_nvidia_binding=bool(driver.USE_NV_BINDING))
    torch.manual_seed(17)
    values = torch.randn(1, 4, 3, 5, device="cuda:0")
    targets = torch.tensor([[1, 2]], device="cuda:0", dtype=torch.long)
    input_lengths = torch.tensor([4], device="cuda:0", dtype=torch.long)
    target_lengths = torch.tensor([2], device="cuda:0", dtype=torch.long)
    results = []
    for dtype in (torch.float32, torch.float16):
        logits = values.to(dtype).detach().requires_grad_(True)
        cuda.as_cuda_array(logits.detach())
        criterion = RNNTLoss(num_classes=4, reduction="mean_batch", loss_name="warprnnt_numba")
        loss = criterion(log_probs=logits, targets=targets, input_lengths=input_lengths,
                         target_lengths=target_lengths)
        loss.backward()
        torch.cuda.synchronize()
        if (not torch.isfinite(loss).all() or logits.grad is None
                or not torch.isfinite(logits.grad).all() or not torch.count_nonzero(logits.grad)):
            raise RuntimeError("RNNT CUDA smoke test produced invalid loss or gradients")
        results.append({"dtype": str(dtype), "loss": float(loss.detach()),
                        "gradient_norm": float(logits.grad.float().norm())})
    return dict(checked, status="Tiny RNNT CUDA forward/backward passed; pilot not run", checks=results)

verify_plan('.')
write_json('rnnt-cuda-check-report.json', rnnt_cuda_preflight())
print('Tiny RNNT CUDA forward/backward passed.')
